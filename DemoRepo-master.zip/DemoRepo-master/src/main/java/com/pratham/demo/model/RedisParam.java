package com.pratham.demo.model;

import io.swagger.v3.oas.annotations.Hidden;
import lombok.*;

import javax.validation.constraints.Pattern;

/**
 *
 * @author Prathamesh1.Patil
 * @DevelopedOn 19-May-2022
 *
 */

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder(toBuilder = true)
public class RedisParam {

    @Pattern(
            regexp = "YES|NO",
            message = "Value should be YES or NO"
    )
    private String isRedisActive;

    @Hidden
    private String key;
}
