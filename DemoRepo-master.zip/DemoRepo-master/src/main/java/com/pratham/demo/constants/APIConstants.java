package com.pratham.demo.constants;

/**
 *
 * @author Prathamesh1.Patil
 * @DevelopedOn 19-May-2022
 *
 */

public interface APIConstants {

    String FORWARD_SLASH = "/";
    String VERSION_V1 = FORWARD_SLASH + "api" + FORWARD_SLASH + "v1";

    String MASTER_FIND_USER = "/findUser";
    String MASTER_GET_USER = "/getUser/{userName}";
    String MASTER_GET_PARTNER_USER = "/getMaster/{userName}";
    String MASTER_GET_SHIP_DETAILS = "/getShipDetails";
    String MASTER_GET_ALL_USER = "/getAllUser";
}
