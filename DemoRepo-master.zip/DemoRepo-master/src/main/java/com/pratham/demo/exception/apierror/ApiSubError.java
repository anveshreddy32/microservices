package com.pratham.demo.exception.apierror;

public interface ApiSubError {
}
