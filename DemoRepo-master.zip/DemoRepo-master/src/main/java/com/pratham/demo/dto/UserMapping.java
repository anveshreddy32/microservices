package com.pratham.demo.dto;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
public class UserMapping implements java.io.Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = 941405620983170576L;
  private Integer id;
  private String domainName;
  private String roleId;
  private String storeCode;
  private Integer dashboardId;
  private String roleName;
  private Integer status;
  private String timestamp;
  private String dashboardName;
  private String empCode;
  private String accessLevel;
  private String state;

}
