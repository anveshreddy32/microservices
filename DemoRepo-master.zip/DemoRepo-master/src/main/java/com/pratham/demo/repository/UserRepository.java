package com.pratham.demo.repository;

import com.pratham.demo.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {

	Optional<User> findByUserNameIgnoreCase(String userName);

	List<User> findByUserType(String userType);

	List<User> findByUserNameInAndStatus(List<String> domains, Integer status);
}
