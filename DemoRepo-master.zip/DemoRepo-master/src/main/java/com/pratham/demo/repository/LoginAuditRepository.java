package com.pratham.demo.repository;

import com.pratham.demo.entity.LoginAudit;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface LoginAuditRepository extends JpaRepository<LoginAudit, Long> {
    Optional<LoginAudit> findByUserId(long userId);
}
