package com.pratham.demo.exception;

import org.springframework.http.HttpStatus;

public class ApplicationTokenizedException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	private HttpStatus httpStatus;
	private int errorCode;
	private String token;
	private String[] msgArgs;

	public HttpStatus getHttpStatus() {
		return httpStatus;
	}

	public int getErorrCode() {
		return errorCode;
	}

	public String[] getMsgArgs() {
		return msgArgs;
	}
	
	public String getToken() {
		return token;
	}

	public ApplicationTokenizedException(int erorrCode, String message, String token) {
		super(message);
		this.errorCode = erorrCode;
		this.token = token;
	}

	public ApplicationTokenizedException(int erorrCode, String message, HttpStatus httpStatus, String token) {
		super(message);
		this.errorCode = erorrCode;
		this.httpStatus = httpStatus;
		this.token = token;
	}

	public ApplicationTokenizedException(int erorrCode, String message, Throwable cause, String token) {
		super(message, cause);
		this.errorCode = erorrCode;
		this.token = token;
	}

	public ApplicationTokenizedException(int erorrCode, HttpStatus httpStatus, String message, Throwable cause, String token) {
		super(message, cause);
		this.errorCode = erorrCode;
		this.httpStatus = httpStatus;
		this.token = token;
	}

	public ApplicationTokenizedException(int erorrCode, HttpStatus httpStatus, String message, String[] msgArgs, String token) {
		super(message);
		this.errorCode = erorrCode;
		this.httpStatus = httpStatus;
		this.token = token;
		if (msgArgs.length > 0) {
			this.msgArgs = msgArgs;
		}
	}

	public ApplicationTokenizedException(int erorrCode, HttpStatus httpStatus, String message, String[] msgArgs,
										 Throwable cause, String token) {
		super(message, cause);
		this.errorCode = erorrCode;
		this.httpStatus = httpStatus;
		this.token = token;
		if (msgArgs.length > 0) {
			this.msgArgs = msgArgs;
		}
	}

}
