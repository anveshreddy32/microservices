package com.pratham.demo.activity;

import com.pratham.demo.entity.LoginAudit;
import com.pratham.demo.model.RedisParam;
import com.pratham.demo.model.UserOutputParam;
import com.pratham.demo.model.UserResponse;

import java.util.List;

/**
 *
 * @author Prathamesh1.Patil
 * @DevelopedOn 19-May-2022
 *
 */

public interface MasterApiActivity {
    UserResponse getUser(String userName);

    List<UserOutputParam> getAllUser(RedisParam param, String type);

    void saveLoginDetails(LoginAudit loginHistory, LoginAudit lastLogin);
}
