package com.pratham.demo.model;

import com.pratham.demo.entity.User;
import lombok.*;

/**
 *
 * @author Prathamesh1.Patil
 * @DevelopedOn 19-May-2022
 *
 */

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class UserResponse {

    private User user;

    private String lastLoginTime;

}
