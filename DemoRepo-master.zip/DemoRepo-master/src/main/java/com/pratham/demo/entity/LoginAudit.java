package com.pratham.demo.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "login_audit")
@EntityListeners(AuditingEntityListener.class)
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder(toBuilder = true)
public class LoginAudit {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long loginId;

    @Column(name = "loginTime")
    private Date loginTime;

    @Column(name = "userId", length = 10)
    private long userId;

    public LoginAudit(Date loginTime, long userId){
        this.loginTime=loginTime;
        this.userId=userId;
    }

}
