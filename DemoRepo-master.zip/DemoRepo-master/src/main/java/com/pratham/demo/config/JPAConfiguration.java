package com.pratham.demo.config;

import com.pratham.demo.util.EncryptDecryptHelper;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import javax.sql.DataSource;


@Configuration
@PropertySource("application.yml")
public class JPAConfiguration {
		
	@Value("${spring.datasource.url}")
    private String URL;
	@Value("${spring.datasource.username}")
    private String USER_NAME;
	@Value("${spring.datasource.password}")
    private String PASSWORD;	
	@Value("${encrypt.key}")
    private String ENC_KEY;
	@Value("${encrypt.key-store.type}")
    private String ENC_INIT_VECTOR;

	@Bean
	public DataSource getDataSource() {
		final String tokenKey=ENC_KEY.strip();
		final String initKey=ENC_INIT_VECTOR.strip();
		HikariConfig config = new HikariConfig();
		 	config.setJdbcUrl(URL.strip());
	        config.setUsername(USER_NAME.strip());
	        config.setPassword(EncryptDecryptHelper.decrypt256(tokenKey, initKey, EncryptDecryptHelper.decryptUtilities(PASSWORD.strip())));
	        
		HikariDataSource hds=new HikariDataSource(config);

		return hds;
	}

}
