package com.pratham.demo.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.data.redis.RedisProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cache.Cache;
import org.springframework.cache.annotation.CachingConfigurerSupport;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.interceptor.CacheErrorHandler;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.JdkSerializationRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;
import org.springframework.data.redis.serializer.StringRedisSerializer;

/**
 * 
 * lettuce uses internally all the properties related to redis defined in yml
 * file.
 *
 */
@Slf4j
@Configuration
@ConditionalOnClass(RedisOperations.class) // There are RedisOperations Class time
@EnableConfigurationProperties(RedisProperties.class) // start-up RedisProperties This class
@PropertySource("application.yml")
@EnableCaching
public class RedisConfiguration extends CachingConfigurerSupport {
	@Autowired
	RedisTemplate redisTemplate;

	@Bean
	@Primary
	public RedisCacheManager cacheManager(RedisConnectionFactory connectionFactory) {

		redisTemplate.setConnectionFactory(connectionFactory);

		// Open AutoType globally, not recommended
		RedisCacheConfiguration config = RedisCacheConfiguration.defaultCacheConfig()
				// .entryTtl(Duration.ofSeconds(14400)) // 4 hrs cache
				// Set up key Serialization of
				.serializeKeysWith(
						RedisSerializationContext.SerializationPair.fromSerializer(new StringRedisSerializer()))
				// Set up value Serialization of
				.serializeValuesWith(RedisSerializationContext.SerializationPair
						.fromSerializer(new JdkSerializationRedisSerializer()))
				// No caching null value
				.disableCachingNullValues();
		RedisCacheManager redisCacheManager = RedisCacheManager.builder(connectionFactory).cacheDefaults(config)
				.transactionAware().build();
		return redisCacheManager;
	}

	@Override
	public CacheErrorHandler errorHandler() {
		return new CacheErrorHandler() {
			@Override
			public void handleCacheGetError(RuntimeException exception, Cache cache, Object key) {
				log.error("Failure getting from cache: " + cache.getName() + ", exception: " + exception.toString());
			}

			@Override
			public void handleCachePutError(RuntimeException exception, Cache cache, Object key, Object value) {
				log.error("Failure putting into cache: " + cache.getName() + ", exception: " + exception.toString());
			}

			@Override
			public void handleCacheEvictError(RuntimeException exception, Cache cache, Object key) {
				log.error("Failure evicting from cache: " + cache.getName() + ", exception: " + exception.toString());
			}

			@Override
			public void handleCacheClearError(RuntimeException exception, Cache cache) {
				log.error("Failure clearing cache: " + cache.getName() + ", exception: " + exception.toString());
			}
		};
	}

}