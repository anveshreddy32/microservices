package com.pratham.demo.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 *
 * @author Prathamesh1.Patil
 * @DevelopedOn 19-May-2022
 *
 */

@AllArgsConstructor
@NoArgsConstructor
@Data
@SuperBuilder(toBuilder = true)
public class UserInputParam {
    private RedisParam param;
    private String type;
}
