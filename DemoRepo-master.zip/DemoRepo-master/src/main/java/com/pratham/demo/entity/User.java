package com.pratham.demo.entity;

import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import javax.persistence.*;
import java.util.Date;

/**
 *
 * @author Prathamesh1.Patil
 * @DevelopedOn 19-May-2022
 *
 */

@Entity
@Table(name = "user")
@EntityListeners(AuditingEntityListener.class)
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder(toBuilder = true)
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long userId;

	@Column(name = "userName", length = 75)
	private String userName;

	@Column(name = "name", length = 75)
	private String name;

	@Column(name = "mobile", length = 13)
	private String mobile;

	@Column(name = "email", length = 75)
	private String email;

	@Column(name = "userType", length = 75)
	private String userType;

	@Column(name = "status")
	private Integer status;

	@CreatedDate
	@Column(name = "create_date", updatable = false)
	private Date createDate;

	@LastModifiedDate
	@Column(name = "modified_date")
	private Date modifiedDate;

	public User(String userName, String name, String mobile, String email, String userType) {
		super();
		this.userName = userName;
		this.name = name;
		this.mobile = mobile;
		this.email = email;
		this.userType = userType;
	}

	public User(Integer status) {
		super();
		this.status = status;
	}

}
