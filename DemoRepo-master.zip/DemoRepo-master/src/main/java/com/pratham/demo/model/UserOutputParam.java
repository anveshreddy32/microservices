package com.pratham.demo.model;

import com.pratham.demo.entity.User;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.io.Serializable;

/**
 *
 * @author Prathamesh1.Patil
 * @DevelopedOn 19-May-2022
 *
 */

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@SuperBuilder(toBuilder = true)
public class UserOutputParam implements Serializable {
    private static final long serialVersionUID = 1L;

    private User user;
    private String lastLoginTime;
}
