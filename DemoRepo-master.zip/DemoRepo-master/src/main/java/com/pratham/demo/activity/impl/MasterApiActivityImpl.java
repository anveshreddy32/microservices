package com.pratham.demo.activity.impl;

import com.pratham.demo.activity.MasterApiActivity;
import com.pratham.demo.entity.LoginAudit;
import com.pratham.demo.entity.User;
import com.pratham.demo.exception.UserNotFoundException;
import com.pratham.demo.model.RedisParam;
import com.pratham.demo.model.UserOutputParam;
import com.pratham.demo.model.UserResponse;
import com.pratham.demo.repository.LoginAuditRepository;
import com.pratham.demo.repository.UserRepository;
import com.pratham.demo.util.UtilConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author Prathamesh1.Patil
 * @DevelopedOn 19-May-2022
 *
 */

@Service
@Transactional
@Slf4j
public class MasterApiActivityImpl implements MasterApiActivity {

    @Autowired
    UserRepository userRepository;

    @Autowired
    LoginAuditRepository loginAuditRepository;


    @Override
    public UserResponse getUser(String userName) {
        UserResponse userResponse = new UserResponse();
        User user;
        Optional<User> optional = userRepository.findByUserNameIgnoreCase(userName);

        if (optional.isPresent()) {
            user = optional.get();
            userResponse.setUser(user);
            Optional<LoginAudit> lastLoginOptional = loginAuditRepository.findByUserId(user.getUserId());
            if (lastLoginOptional.isPresent()) {
                LoginAudit lastLogin = lastLoginOptional.get();
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
                String lastLoginTime = format.format(lastLogin.getLoginTime());

                userResponse.setLastLoginTime(lastLoginTime);
                LoginAudit loginHistory = new LoginAudit(new Date(), user.getUserId());
                saveLoginDetails(loginHistory, lastLogin);
            } else {
                userResponse.setLastLoginTime("");
                LoginAudit loginHistory = new LoginAudit(new Date(), user.getUserId());
                loginAuditRepository.save(loginHistory);
            }
            if (UtilConstants.EMPLOYEE.equalsIgnoreCase(user.getUserType())) {
                getEmployeeDetails(userResponse, user);

            } else {
                getPartnerDetails(userResponse, user);
            }
        } else
            throw new UserNotFoundException(userName + " User Not Found");
        return userResponse;

    }

    private void getPartnerDetails(UserResponse userResponse, User user) {
        //your code
    }

    private void getEmployeeDetails(UserResponse userResponse, User user) {
        //your code
    }

    @Override
    public List<UserOutputParam> getAllUser(RedisParam param, String type) {
        return null;
    }

    @Override
    public void saveLoginDetails(LoginAudit loginHistory, LoginAudit lastLogin) {
        BeanUtils.copyProperties(loginHistory, lastLogin, "loginId");
        BeanUtils.copyProperties(lastLogin, loginHistory);
        loginAuditRepository.save(loginHistory);
    }
}
