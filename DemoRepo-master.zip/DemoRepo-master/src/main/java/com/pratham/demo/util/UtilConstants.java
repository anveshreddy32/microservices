package com.pratham.demo.util;

public interface UtilConstants {

    String EMPLOYEE = "Employee";
    String CUSTOMER = "Customer";

    enum key {
        POSITION("position"), PARTNER("partner"), CHANNEL("channel"), TYPE("type"), GROUP("group"),
        EMPLOYEE("employee"),CUSTOMER("customer"), MAPPING("mapping"), TEMPLATE("msgTemplate"), APPROVAL_DEFINITION("approvalDefinition"),
        USER("user"), BRAND_WISE("brandWise"), FAMILY_WISE("familyWise"), SITEPLANT("siteplant"), BRAND("brand"),
        FAMILY("family");

        private final String name;

        private key(String name) {
            this.name = name;
        }

        public String getValue() {
            return name;
        }
    }
}
