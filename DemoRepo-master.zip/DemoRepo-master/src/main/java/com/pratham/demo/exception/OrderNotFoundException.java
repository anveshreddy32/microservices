package com.pratham.demo.exception;

/**
 *
 * @author Atul.Kurne
 * @DevelopedOn 24-Sep-2021
 *
 */

public class OrderNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
