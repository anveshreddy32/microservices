package com.pratham.demo.controller;

import com.pratham.demo.constants.APIConstants;
import com.pratham.demo.model.*;
import com.pratham.demo.service.MasterApiService;
import com.pratham.demo.util.UtilConstants;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springdoc.api.ErrorMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

/**
 *
 * @author Prathamesh1.Patil
 * @DevelopedOn 19-May-2022
 *
 */

@RestController
@Slf4j
@RequestMapping(path = APIConstants.VERSION_V1)
@RefreshScope
public class MasterApiController {

	@Autowired
	MasterApiService masterService;

	@Operation(summary = "Get User")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Get User", content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = UserResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Invalid Get User paramters", content = {
					@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class)) }),
			@ApiResponse(responseCode = "404", description = "User not found", content = {
					@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class)) }),
			@ApiResponse(responseCode = "500", description = "User internal server error", content = {
					@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class)) }) })
	@GetMapping(path = { APIConstants.MASTER_GET_USER }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public UserResponse getUser(@PathVariable(name = "userName") String userName) {
		UserResponse userResponse = masterService.getUser(userName);
		return userResponse;
	}

	@Operation(summary = "Get ALL User")
	@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Get User", content = {
			@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = UserResponse.class)) }),
			@ApiResponse(responseCode = "400", description = "Invalid Get User paramters", content = {
					@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class)) }),
			@ApiResponse(responseCode = "404", description = "User not found", content = {
					@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class)) }),
			@ApiResponse(responseCode = "500", description = "User internal server error", content = {
					@Content(mediaType = MediaType.APPLICATION_JSON_VALUE, schema = @Schema(implementation = ErrorMessage.class)) }) })
	@PostMapping(path = { APIConstants.MASTER_GET_ALL_USER }, consumes = {
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
	public List<UserOutputParam> getAllUser(@Valid @RequestBody UserInputParam inputParam) {
		String type = inputParam.getType();
		RedisParam param = inputParam.getParam();
		if (StringUtils.isEmpty(type)) {
			param = param.toBuilder().key(UtilConstants.key.USER.getValue()).build();
		} else if (type.equals(UtilConstants.EMPLOYEE)) {
			param = param.toBuilder()
					.key(String.join("-", UtilConstants.key.USER.getValue(), UtilConstants.key.EMPLOYEE.getValue()))
					.build();
		} else if (type.equals(UtilConstants.CUSTOMER)) {
			param = param.toBuilder()
					.key(String.join("-", UtilConstants.key.USER.getValue(), UtilConstants.key.CUSTOMER.getValue()))
					.build();
		}

		List<UserOutputParam> users = masterService.getAllUser(param, type);
		return users;
	}

}
