package com.pratham.demo.exception;

import org.springframework.http.HttpStatus;

public class ApplicationException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	private HttpStatus httpStatus;
	private int errorCode;
	private String[] msgArgs;

	public HttpStatus getHttpStatus() {
		return httpStatus;
	}

	public int getErorrCode() {
		return errorCode;
	}

	public String[] getMsgArgs() {
		return msgArgs;
	}

	public ApplicationException(int erorrCode, String message) {
		super(message);
		this.errorCode = erorrCode;
	}

	public ApplicationException(int erorrCode, String message, HttpStatus httpStatus) {
		super(message);
		this.errorCode = erorrCode;
		this.httpStatus = httpStatus;
	}

	public ApplicationException(int erorrCode, String message, Throwable cause) {
		super(message, cause);
		this.errorCode = erorrCode;
	}

	public ApplicationException(int erorrCode, HttpStatus httpStatus, String message, Throwable cause) {
		super(message, cause);
		this.errorCode = erorrCode;
		this.httpStatus = httpStatus;
	}

	public ApplicationException(int erorrCode, HttpStatus httpStatus, String message, String[] msgArgs) {
		super(message);
		this.errorCode = erorrCode;
		this.httpStatus = httpStatus;
		if (msgArgs.length > 0) {
			this.msgArgs = msgArgs;
		}
	}

	public ApplicationException(int erorrCode, HttpStatus httpStatus, String message, String[] msgArgs,
								Throwable cause) {
		super(message, cause);
		this.errorCode = erorrCode;
		this.httpStatus = httpStatus;
		if (msgArgs.length > 0) {
			this.msgArgs = msgArgs;
		}
	}

}
