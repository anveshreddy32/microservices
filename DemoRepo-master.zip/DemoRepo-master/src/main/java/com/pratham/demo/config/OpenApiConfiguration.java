package com.pratham.demo.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.servers.Server;
import lombok.AllArgsConstructor;
import org.springframework.context.annotation.Bean;

//@Configuration
//@OpenAPIDefinition(info = @Info(title = "OMS Master Service API", version = "1.0", description = "OMS Master Service Information"))
@AllArgsConstructor

public class OpenApiConfiguration {

	@Bean
	public OpenAPI customeOpenAPI(OpenApiProperties openApiProperties) {
		return new OpenAPI().addServersItem(
				new Server().url(openApiProperties.getUrl()).description(openApiProperties.getDescription()));

	}

}
