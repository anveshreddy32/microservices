package com.pratham.demo.service.impl;

import com.pratham.demo.activity.MasterApiActivity;
import com.pratham.demo.model.RedisParam;
import com.pratham.demo.model.UserOutputParam;
import com.pratham.demo.model.UserResponse;
import com.pratham.demo.service.MasterApiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 *
 * @author Prathamesh1.Patil
 * @DevelopedOn 19-May-2022
 *
 */

@Service
public class MasterApiServiceImpl implements MasterApiService {

    @Autowired
    MasterApiActivity masterApiActivity;

    @Override
    public UserResponse getUser(String userName) {
        UserResponse userResponse = masterApiActivity.getUser(userName);
        return userResponse;
    }

    @Override
    public List<UserOutputParam> getAllUser(RedisParam param, String type) {
        List<UserOutputParam> users=masterApiActivity.getAllUser(param,type);
        return users;
    }
}
