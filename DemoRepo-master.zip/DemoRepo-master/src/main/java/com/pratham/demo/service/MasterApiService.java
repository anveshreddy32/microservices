package com.pratham.demo.service;

import com.pratham.demo.model.RedisParam;
import com.pratham.demo.model.UserOutputParam;
import com.pratham.demo.model.UserResponse;
import org.springframework.stereotype.Service;

import java.util.List;


/**
 *
 * @author Prathamesh1.Patil
 * @DevelopedOn 19-May-2022
 *
 */


public interface MasterApiService {
    UserResponse getUser(String userName);

    List<UserOutputParam> getAllUser(RedisParam param, String type);
}
